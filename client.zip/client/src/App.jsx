import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import RiskAssessment from "./pages/RiskAssessment";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />

      {/* NEW PAGE */}
      <Route
        path="/risk"
        element={
          <RiskAssessment
            analysis={{
              patient_id: "PATIENT_ABC123",
              drug: "CODEINE",
              risk_assessment: {
                risk_label: "Unknown",
                confidence_score: 0.5,
                severity: "none"
              },
              pharmacogenomic_profile: {
                primary_gene: "UNKNOWN",
                diplotype: "*?/*?",
                phenotype: "Unknown",
                detected_variants: []
              },
              clinical_recommendation: {
                dosing_guidance: "No recommendation available in Phase 1",
                alternative_therapy: "N/A"
              },
              llm_generated_explanation: {
                biological_mechanism: "Not determined.",
                variant_citation: []
              }
            }}
          />
        }
      />
    </Routes>
  );
}
