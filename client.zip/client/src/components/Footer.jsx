export default function Footer() {
  return (
    <footer className="border-t border-slate-200 py-6 text-center text-sm text-slate-500">
      © 2026 HELIX. All rights reserved.
    </footer>
  );
}
